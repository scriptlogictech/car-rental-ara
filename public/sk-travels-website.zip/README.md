# S K Travels – Car Rental in Arrah, Bihar
Chauffeur-Driven White Mahindra Scorpio Car Rental & Taxi Service

- Location: Old Police Line, Arrah, Bhojpur, Bihar - 802301
- Phone: +91 6204671213
- Primary Vehicle: White Mahindra Scorpio (With Driver)

## Quick Start
1. Run `npm install`
2. Run `npm run dev`
3. Visit http://localhost:3000

## Build for Production
Run `npm run build` to generate the static files in the `dist/` folder.
